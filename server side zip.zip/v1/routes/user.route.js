const router = require("express").Router();
const fileUploader = require("../helpers/middlewares/fileUploader");
const updateFileName = require("../helpers/middlewares/updateFileName");
const {
  handleCreate,
  handleDelete,
  handleGetAll,
  handleGetOne,
  handleUpdate,
} = require("../controllers/user.controller");
const autorize = require("../helpers/middlewares/authorization");

router.post(
  "/",
  autorize(["superadmin"]),
  fileUploader("avatar").single("avatar"),
  updateFileName("avatar", "avatar"),
  handleCreate
);
router.put(
  "/:id",
  autorize(["superadmin", "admin"]),
  fileUploader("avatar").single("avatar"),
  updateFileName("avatar", "avatar"),
  handleUpdate
);
router.delete("/:id", autorize(["superadmin", "admin"]), handleDelete);
router.get("/:id", autorize(["superadmin", "admin"]), handleGetOne);
router.get("/", autorize(["superadmin"]), handleGetAll);

module.exports = router;
